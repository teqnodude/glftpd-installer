#ifndef _DIZREADER_H_
#define _DIZREADER_H_

void removespaces(char *, int);
//int read_diz(char *);
int read_diz(void);

#endif
